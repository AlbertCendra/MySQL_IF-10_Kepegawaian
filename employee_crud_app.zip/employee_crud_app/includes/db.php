<?php
$host = 'localhost';
$username = 'root';   // Ganti dengan username MySQL Anda
$password = '';       // Ganti dengan password MySQL Anda
$dbname = 'kepegawaian';  // Ganti dengan nama database Anda

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Koneksi gagal: " . $e->getMessage();
}
?>
