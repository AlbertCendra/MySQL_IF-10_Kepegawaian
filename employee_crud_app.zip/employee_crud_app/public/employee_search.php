<?php
include '../includes/db.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM employees";

// Add search filter if there's a search term
if ($search != '') {
    $query .= " WHERE name LIKE :search OR position LIKE :search OR department LIKE :search";
}

$stmt = $conn->prepare($query);

if ($search != '') {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}

// Loop through the results and display each employee row
while ($employee = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>
            <td>{$employee['id']}</td>
            <td>{$employee['name']}</td>
            <td>{$employee['position']}</td>
            <td>{$employee['salary']}</td>
            <td>{$employee['department']}</td>
            <td>
                <a href='edit_employee.php?id={$employee['id']}' class='btn btn-warning'>Edit</a>
                <a href='delete_employee.php?id={$employee['id']}' class='btn btn-danger'>Delete</a>
            </td>
        </tr>";
}
?>
