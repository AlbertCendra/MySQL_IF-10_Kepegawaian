<?php
session_start();

// Cek apakah pengguna sudah login
if (isset($_SESSION['user_id'])) {
    // Pastikan 'username' ada dalam session
    $username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Pengguna'; // Default ke 'Pengguna' jika tidak ada
    $greeting = "Halo, $username!"; // Menampilkan salam untuk pengguna
} else {
    $greeting = "Selamat datang! Silakan login untuk melanjutkan.";
}

date_default_timezone_set('Asia/Jakarta'); // Set timezone sesuai lokasi
$hour = date('H'); // Ambil jam saat ini

// Greet based on time of day
if ($hour >= 5 && $hour < 12) {
    $timeGreeting = "Selamat Pagi!";
} elseif ($hour >= 12 && $hour < 18) {
    $timeGreeting = "Selamat Siang!";
} else {
    $timeGreeting = "Selamat Malam!";
}

include '../includes/db.php'; // Menyertakan koneksi database

// Ambil pengumuman terbaru dari database
$stmt = $conn->prepare("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 1");
$stmt->execute();
$announcement = $stmt->fetch(PDO::FETCH_ASSOC);

// Ambil jumlah pegawai dari database
$stmtEmployees = $conn->prepare("SELECT COUNT(*) AS total_employees FROM employees");
$stmtEmployees->execute();
$data = $stmtEmployees->fetch(PDO::FETCH_ASSOC);
$totalEmployees = $data['total_employees'];

?>

<?php include '../includes/header.php'; ?>
<div class="container mt-5">
    <!-- Header Greeting -->
    <div class="jumbotron text-center">
        <h1 class="display-4"><?php echo $timeGreeting; ?> <?php echo $greeting; ?></h1>
        <p class="lead">Aplikasi ini memungkinkan Anda untuk mengelola data pegawai dengan mudah dan efisien. Daftarkan pegawai baru, lihat data pegawai, dan lakukan manajemen data dengan mudah.</p>
        <hr class="my-4">
        <p>Dengan aplikasi ini, Anda bisa:</p>
        <ul class="list-unstyled">
            <li><i class="fas fa-check-circle"></i> Menambah data pegawai baru</li>
            <li><i class="fas fa-check-circle"></i> Mengedit data pegawai yang ada</li>
            <li><i class="fas fa-check-circle"></i> Menghapus data pegawai</li>
            <li><i class="fas fa-check-circle"></i> Lihat semua data pegawai dalam satu halaman</li>
        </ul>
        <p class="lead">
            <a class="btn btn-primary btn-lg" href="register.php" role="button">Daftar Akun</a>
            <a class="btn btn-success btn-lg" href="employee_list.php" role="button">Lihat Data Pegawai</a>
        </p>
    </div>

    <!-- Pengumuman Terbaru -->
    <?php if ($announcement): ?>
    <div class="alert alert-info" role="alert">
        <strong>Pengumuman:</strong> <?php echo $announcement['title']; ?> - <?php echo $announcement['content']; ?>
    </div>
    <?php endif; ?>

    <!-- Fitur Tentang Aplikasi -->
    <div class="row mt-5">
        <div class="col-lg-6">
            <h3>Kenapa Menggunakan Aplikasi Ini?</h3>
            <p>Aplikasi Kepegawaian ini dirancang untuk membantu Anda mengelola data pegawai dengan mudah. Dilengkapi dengan fitur untuk menambah, mengedit, menghapus, dan melihat data pegawai dalam satu tempat. Semua data akan disimpan secara aman dalam database, memudahkan pengelolaan SDM dalam organisasi Anda.</p>
        </div>
        <div class="col-lg-6">
            <h3>Fitur Utama</h3>
            <ul class="list-unstyled">
                <li><i class="fas fa-check-circle"></i> Tambah Pegawai Baru</li>
                <li><i class="fas fa-check-circle"></i> Edit Data Pegawai</li>
                <li><i class="fas fa-check-circle"></i> Hapus Data Pegawai</li>
                <li><i class="fas fa-check-circle"></i> Lihat Semua Pegawai dalam Tabel</li>
                <li><i class="fas fa-check-circle"></i> Manajemen Pengguna untuk Keamanan</li>
            </ul>
        </div>
    </div>

    <!-- Statistik Pegawai -->
    <div class="row mt-5">
        <div class="col-md-12 text-center">
            <h3>Total Pegawai Terdaftar: <?php echo $totalEmployees; ?> Pegawai</h3>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
