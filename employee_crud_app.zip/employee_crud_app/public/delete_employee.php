<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include '../includes/db.php';  // Koneksi ke database

// Cek apakah ada ID pegawai yang diberikan
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus data pegawai
    $stmt = $conn->prepare("DELETE FROM employees WHERE id = :id");
    if ($stmt->execute(['id' => $id])) {
        // Redirect ke dashboard setelah berhasil menghapus dengan pesan sukses
        $_SESSION['success_message'] = 'Pegawai berhasil dihapus!';
        header('Location: employee_list.php');
        exit();
    } else {
        echo "Error deleting employee.";
    }
} else {
    header('Location: employee_list.php');
    exit();
}
