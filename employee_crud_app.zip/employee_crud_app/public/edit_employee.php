<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include '../includes/db.php';  // Koneksi ke database

// Cek apakah ada ID pegawai yang diberikan
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data pegawai yang akan diedit
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        header('Location: employee_list.php');
        exit();
    }

    // Proses jika form disubmit
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        $position = $_POST['position'];
        $salary = $_POST['salary'];
        $department = $_POST['department'];

        // Validasi input
        if (empty($name) || empty($position) || empty($salary) || empty($department)) {
            $error = "Semua kolom harus diisi!";
        } else {
            // Update data pegawai
            $stmt = $conn->prepare("UPDATE employees SET name = :name, position = :position, salary = :salary, department = :department WHERE id = :id");
            if ($stmt->execute(['name' => $name, 'position' => $position, 'salary' => $salary, 'department' => $department, 'id' => $id])) {
                // Set success message and redirect to dashboard
                $_SESSION['success_message'] = 'Data pegawai berhasil diperbarui!';
                header('Location: employee_list.php');
                exit();
            } else {
                $error = "Gagal memperbarui pegawai.";
            }
        }
    }
} else {
    header('Location: employee_list.php');
    exit();
}
?>

<?php include '../includes/header.php'; ?>
<div class="container">
    <h2>Edit Pegawai</h2>
    <?php if (isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>
    <form method="POST">
        <div class="form-group">
            <label for="name">Nama:</label>
            <input type="text" class="form-control" name="name" id="name" value="<?php echo $employee['name']; ?>" required>
        </div>
        <div class="form-group">
            <label for="position">Jabatan:</label>
            <input type="text" class="form-control" name="position" id="position" value="<?php echo $employee['position']; ?>" required>
        </div>
        <div class="form-group">
            <label for="salary">Gaji:</label>
            <input type="number" class="form-control" name="salary" id="salary" value="<?php echo $employee['salary']; ?>" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="department">Departemen:</label>
            <input type="text" class="form-control" name="department" id="department" value="<?php echo $employee['department']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Pegawai</button>
    </form>
</div>
<?php include '../includes/footer.php'; ?>
