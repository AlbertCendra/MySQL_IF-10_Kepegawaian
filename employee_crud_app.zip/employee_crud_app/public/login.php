<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '../includes/db.php';  // Koneksi ke database
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek apakah username ada di database
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verifikasi password
    if ($user && password_verify($password, $user['password'])) {
        // Simpan user_id di session untuk login
        $_SESSION['user_id'] = $user['id'];
        echo json_encode(['status' => 'success', 'redirect' => 'index.php']);
        exit();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Kredensial tidak valid']);
        exit();
    }
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kepegawaian - CRUD</title>
    <!-- W3.CSS -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <!-- FontAwesome for spinner -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS (optional) -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>


<?php include '../includes/header.php'; ?>
<div class="container mt-5">
    <div class="w3-card-4 w3-light-grey" style="max-width: 400px; margin: 0 auto; padding: 30px; border-radius: 15px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);">
        <h2 class="w3-center w3-text-blue">Login</h2>

        <!-- Error message if login fails -->
        <div id="error-message" class="w3-panel w3-red" style="display:none;"></div>

        <form method="POST" id="login-form">
            <div class="w3-input w3-margin-bottom">
                <label for="username"><b>Username:</b></label>
                <input type="text" name="username" id="username" class="w3-input w3-border w3-round" required>
            </div>
            <div class="w3-input w3-margin-bottom">
                <label for="password"><b>Password:</b></label>
                <input type="password" name="password" id="password" class="w3-input w3-border w3-round" required>
            </div>
            <button type="submit" id="login-button" class="w3-btn w3-blue w3-round w3-block w3-hover-shadow">Login</button>
            <div id="loading" style="display:none;" class="w3-center w3-padding-16">
                <i class="fa fa-spinner fa-spin w3-large"></i> Please wait...
            </div>
        </form>

        <!-- Tombol Register jika belum punya akun -->
        <div class="w3-center mt-3">
            <p>Belum punya akun? <a href="register.php" class="w3-btn w3-light-grey w3-round">Daftar Sekarang</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Include jQuery and AJAX for form submission -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Handle form submission
        $('#login-form').submit(function(e) {
            e.preventDefault(); // Prevent page refresh
            var username = $('#username').val();
            var password = $('#password').val();

            // Show loading spinner and hide the button
            $('#loading').show();
            $('#login-button').hide();

            // Perform AJAX request
            $.ajax({
                url: 'login.php',
                method: 'POST',
                data: { username: username, password: password },
                dataType: 'json',
                success: function(response) {
                    // Hide the loading spinner
                    $('#loading').hide();

                    if (response.status === 'success') {
                        // Redirect to the dashboard
                        window.location.href = response.redirect;
                    } else {
                        // Show error message
                        $('#error-message').text(response.message).show();
                        $('#login-button').show();
                    }
                },
                error: function() {
                    // Hide loading spinner and show button again
                    $('#loading').hide();
                    $('#login-button').show();
                    $('#error-message').text('Something went wrong. Please try again.').show();
                }
            });
        });
    });
</script>
