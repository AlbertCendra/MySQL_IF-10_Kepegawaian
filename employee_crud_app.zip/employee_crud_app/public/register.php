<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '../includes/db.php';  // Koneksi ke database
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Enkripsi password

    // Cek apakah username sudah ada di database
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Jika username sudah ada, beri pesan error
        $error = "Username sudah terdaftar. Silakan pilih username lain.";
    } else {
        // Simpan data pengguna baru jika username belum ada
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
        if ($stmt->execute(['username' => $username, 'password' => $password])) {
            // Redirect ke halaman login setelah berhasil mendaftar
            header('Location: login.php');
            exit();
        } else {
            $error = "Pendaftaran gagal. Coba lagi.";
        }
    }
}
?>

<?php include '../includes/header.php'; ?>
<div class="w3-card-4">
    <h2>Daftar Akun</h2>
    <?php if (isset($error)) { echo "<div class='w3-panel w3-red'>$error</div>"; } ?>
    <form method="POST">
        <div class="w3-input">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" class="w3-input" required>
        </div>
        <div class="w3-input">
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" class="w3-input" required>
        </div>
        <button type="submit" class="w3-btn">Daftar</button>
    </form>

    <p class="w3-center">
        <a href="login.php" class="w3-button w3-light-grey">Sudah punya akun? Login</a>
    </p>
</div>

<?php include '../includes/footer.php'; ?>
