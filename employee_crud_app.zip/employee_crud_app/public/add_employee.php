<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '../includes/db.php';  // Koneksi ke database

    // Mengambil data dari form
    $name = $_POST['name'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];
    $department = $_POST['department'];

    // Validasi input
    if (empty($name) || empty($position) || empty($salary) || empty($department)) {
        $error = "Semua kolom harus diisi!";
    } else {
        // Query untuk memasukkan data pegawai baru
        $stmt = $conn->prepare("INSERT INTO employees (name, position, salary, department) VALUES (:name, :position, :salary, :department)");
        $params = [
            'name' => $name,
            'position' => $position,
            'salary' => $salary,
            'department' => $department
        ];
        
        if ($stmt->execute($params)) {
            // Redirect ke dashboard setelah berhasil menambah dengan pesan sukses
            $_SESSION['success_message'] = 'Pegawai berhasil ditambahkan!';
            header('Location: employee_list.php');
            exit();
        } else {
            $error = "Gagal menambahkan pegawai.";
        }
    }
}
?>

<?php include '../includes/header.php'; ?>
<div class="container mt-5">
    <h2>Tambah Pegawai</h2>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    <form method="POST">
        <!-- Form fields untuk input data pegawai -->
        <div class="form-group">
            <label for="name">Nama:</label>
            <input type="text" class="form-control" name="name" id="name" required>
        </div>
        <div class="form-group">
            <label for="position">Jabatan:</label>
            <input type="text" class="form-control" name="position" id="position" required>
        </div>
        <div class="form-group">
            <label for="salary">Gaji:</label>
            <input type="number" class="form-control" name="salary" id="salary" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="department">Departemen:</label>
            <input type="text" class="form-control" name="department" id="department" required>
        </div>
        <button type="submit" class="btn btn-success">Tambah Pegawai</button>
    </form>
</div>
<?php include '../includes/footer.php'; ?>
