<?php 
session_start();

// Prepare the SQL query for employees
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM employees";

// Include header and db connection
include '../includes/header.php'; 
include '../includes/db.php'; 

// Add search filter if there's a search term
if ($search != '') {
    $query .= " WHERE name LIKE :search OR position LIKE :search OR department LIKE :search";
}

// Prepare the statement
$stmt = $conn->prepare($query);

if ($search != '') {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}

// Fetch the employees from the database and store in $employees
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC); // Now $employees is properly defined

?>

<?php if (isset($_SESSION['success_message'])): ?>
    <div class="alert alert-success">
        <?php echo $_SESSION['success_message']; ?>
        <?php unset($_SESSION['success_message']); ?>
    </div>
<?php endif; ?>

<div class="container mt-5">
    <h2>Data Pegawai</h2>

    <!-- Search Form -->
    <form method="GET" class="form-inline mb-3">
        <input type="text" name="search" class="form-control" placeholder="Cari Pegawai" id="search" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>" onkeyup="searchEmployees()">
        <button type="submit" class="search-btn"></button>
    </form>

    <!-- Tabel Data Pegawai -->
    <a href="add_employee.php" class="btn btn-success mb-3">Tambah Pegawai</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Gaji</th>
                <th>Departemen</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($employees as $employee): ?>
                <tr>
                    <td><?php echo $employee['id']; ?></td>
                    <td><?php echo $employee['name']; ?></td>
                    <td><?php echo $employee['position']; ?></td>
                    <td><?php echo number_format($employee['salary'], 2, ',', '.'); ?></td>
                    <td><?php echo $employee['department']; ?></td>
                    <td>
                        <a href="edit_employee.php?id=<?php echo $employee['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete_employee.php?id=<?php echo $employee['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>

<script>
    function searchEmployees() {
        let search = document.getElementById("search").value;
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "employee_search.php?search=" + search, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Update only the table with the results (tabel data pegawai)
                document.querySelector("tbody").innerHTML = xhr.responseText;
            }
        };
        xhr.send();
    }
</script>
