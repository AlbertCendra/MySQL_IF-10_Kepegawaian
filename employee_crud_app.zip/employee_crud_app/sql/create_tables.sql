-- Membuat Database
CREATE DATABASE IF NOT EXISTS kepegawaian;
USE kepegawaian;

-- Tabel untuk menyimpan data pengguna (untuk login)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel untuk menyimpan data pegawai
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    position VARCHAR(255) NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    department VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Stored Procedure untuk memilih semua pegawai
DELIMITER //
CREATE PROCEDURE get_all_employees()
BEGIN
    SELECT * FROM employees;
END//
DELIMITER ;

-- Trigger untuk membulatkan gaji sebelum memasukkan data pegawai
DELIMITER //
CREATE TRIGGER before_insert_employee
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    SET NEW.salary = ROUND(NEW.salary, 2);  -- Membulatkan gaji
END//
DELIMITER ;
